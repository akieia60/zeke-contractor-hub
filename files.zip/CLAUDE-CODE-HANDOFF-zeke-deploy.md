# CLAUDE CODE HANDOFF — Deploy Zeke Contractor Hub to Vercel
**Date:** April 18, 2026  
**From:** Michael (Claude, MacBook Pro)  
**Executing Agent:** Claude Code  
**Priority:** Execute immediately, no questions needed — all decisions already made

---

## WHAT THIS IS

A complete single-file contractor business app built for **Zeke Shaw** — owner of **North To South Home Remodeling by Zeke Corp.** — a 20+ year general contractor in Alabama with zero digital systems. AK built this for him as a gift/favor.

The app is a fully self-contained HTML file that runs as a mobile web app. It includes:
- Job management dashboard
- Client directory
- Invoice generator with payment splits, signature pads, and material photo uploads
- Job checklist system
- Internal + client notes
- Job activity log
- Company settings
- Pre-loaded demo job (Joyce Griffin, bathroom remodel)

**Tech stack:** Pure HTML/CSS/JavaScript. No frameworks. No build process. No backend. No API keys. No database. Storage uses browser localStorage.

---

## YOUR ONE JOB

**Deploy the file `zeke-contractor-hub-final.html` to Vercel as a new project named `zeke-contractor-hub`.**

The end result should be a live public URL like:  
`https://zeke-contractor-hub.vercel.app`

That URL gets texted to Zeke. He opens it in Safari on his iPhone, taps Share → Add to Home Screen, and it works like a native app forever.

---

## THE FILE

The file to deploy is located at:  
`/mnt/user-data/outputs/zeke-contractor-hub-final.html`

This is the complete, final, ready-to-deploy version. Do not modify the contents.

---

## EXACT DEPLOYMENT STEPS

### Step 1 — Set up the project folder

```bash
mkdir -p ~/zeke-hub
cp /mnt/user-data/outputs/zeke-contractor-hub-final.html ~/zeke-hub/index.html
```

> The file must be renamed to `index.html` — Vercel serves `index.html` as the root page.

### Step 2 — Create the Vercel config file

Create `~/zeke-hub/vercel.json` with exactly this content:

```json
{
  "version": 2,
  "name": "zeke-contractor-hub",
  "builds": [
    { "src": "index.html", "use": "@vercel/static" }
  ],
  "routes": [
    { "src": "/(.*)", "dest": "/index.html" }
  ]
}
```

### Step 3 — Deploy using Vercel CLI

```bash
cd ~/zeke-hub
vercel deploy --prod --yes --name zeke-contractor-hub
```

If Vercel CLI is not installed:
```bash
npm install -g vercel
vercel deploy --prod --yes --name zeke-contractor-hub
```

If CLI auth is needed, use the token from AK's Vercel account. AK's Vercel team ID is `team_J5CBZBSgVSZOAfV3KcH15V8B` (same account as Digital Bloom). Pass token like this:
```bash
vercel deploy --prod --yes --name zeke-contractor-hub --token YOUR_TOKEN_HERE
```

To get the token: vercel.com → Settings → Tokens → Create token named "claude-code-deploy"

### Step 4 — Confirm deployment

After deploy completes, Vercel will output a URL. It should be:
```
https://zeke-contractor-hub.vercel.app
```

Fetch that URL and confirm the page loads (look for "North To South" or "Good to have you back, Zeke" in the response).

---

## EXPECTED FOLDER STRUCTURE BEFORE DEPLOY

```
~/zeke-hub/
├── index.html       ← the app (copied from zeke-contractor-hub-final.html)
└── vercel.json      ← deployment config
```

That's it. Two files. Nothing else needed.

---

## VERCEL ACCOUNT CONTEXT

- AK already has Vercel connected — same account used for Digital Bloom
- Digital Bloom project ID: `prj_5qpU6drgdPH01zhks2DWICsD1aXb`
- Team ID: `team_J5CBZBSgVSZOAfV3KcH15V8B`
- This is a **brand new separate project** — do NOT deploy into the Digital Bloom project
- Free tier is fine — this is a static HTML file, zero cost to host

---

## WHAT THE APP DOES (context only — no action needed)

When Zeke opens the URL he will see:

1. **Dashboard** — shows Joyce Griffin's bathroom remodel job already loaded as a demo ($4,300 quoted, status: Quote Sent)
2. **Her job card** — tap it to see full job details, line items, checklist, notes, invoice preview
3. **+ New Job button** — how he creates every future job
4. **Clients tab** — auto-populates as he adds jobs
5. **Settings tab** — he updates his company info once and it flows to every invoice

Joyce's job is pre-loaded so Zeke sees a real working example immediately. Once he saves his first new real job, the app locks into memory mode and never resets again.

---

## WHAT TO HAND BACK TO AK

Once deployed, give AK:

1. ✅ The live URL: `https://zeke-contractor-hub.vercel.app`
2. ✅ Confirmation it loads correctly
3. ✅ This exact text she can copy and text to Zeke:

---

**TEXT TO SEND ZEKE:**

> Hey Zeke! I built you your own contractor app — it's got your jobs, invoices, client directory, everything. It's FREE and already has Joyce Griffin's bathroom job loaded in there so you can see how it works.
>
> Here's your link: **https://zeke-contractor-hub.vercel.app**
>
> To save it to your home screen like a real app:
> 1. Tap the link — it opens in Safari
> 2. Tap the Share button at the bottom (box with arrow pointing up)
> 3. Scroll down and tap **"Add to Home Screen"**
> 4. Name it whatever you want → tap Add
>
> Now it's on your home screen. Tap it anytime to open your jobs. Always open it from that icon — not the link — so it remembers your data.
>
> Let me know what you think!

---

## WATCH OUT FOR

- If deploy fails with "no credentials" — need to run `vercel login` first or pass `--token`
- If the URL comes out different than expected (like a random hash URL), run `vercel alias` to set the clean domain name
- Do NOT touch or modify `index.html` contents — the file is final and complete
- This is a static deploy only — no serverless functions, no environment variables, nothing else needed

---

## DONE WHEN

- [ ] `https://zeke-contractor-hub.vercel.app` loads in browser
- [ ] Page shows "Good to have you back, Zeke." and Joyce Griffin's job card
- [ ] URL confirmed and handed back to AK
